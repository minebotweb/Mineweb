// Configuração do Firebase com seu projeto real
const firebaseConfig = {
  apiKey: "AIzaSyC_z8UhVlp17sL6RLBiYqwwU_4g-c_uByg",
  authDomain: "cubescape-account.firebaseapp.com",
  projectId: "cubescape-account",
  storageBucket: "cubescape-account.firebasestorage.app",
  messagingSenderId: "63348118324",
  appId: "1:63348118324:web:c69420a5e9b05b3596cb61",
  measurementId: "G-F70R3VNY2L"
};
firebase.initializeApp(firebaseConfig);